import React from "react";

export default function Error(){
    return(
        <h1>ERROR! Page not found.</h1>
    )
}